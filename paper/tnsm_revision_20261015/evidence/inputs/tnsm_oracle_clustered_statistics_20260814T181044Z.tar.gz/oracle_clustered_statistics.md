# Frozen-oracle clustered statistics

| Mode | Metric | Estimate | Scenario-clustered 95% interval |
|---|---|---:|---:|
| NO_RAG | decision accuracy | 0.167 | [0.000, 0.500] |
| NO_RAG | enforced action accuracy | 0.667 | [0.333, 1.000] |
| NO_RAG | coverage | 0.000 | [0.000, 0.000] |
| RAG | decision accuracy | 0.833 | [0.500, 1.000] |
| RAG | enforced action accuracy | 0.833 | [0.500, 1.000] |
| RAG | coverage | 0.667 | [0.333, 1.000] |
| AGENTIC_RAG | decision accuracy | 1.000 | [1.000, 1.000] |
| AGENTIC_RAG | enforced action accuracy | 0.967 | [0.933, 1.000] |
| AGENTIC_RAG | coverage | 0.833 | [0.500, 1.000] |

## Repeat-determinism statement

Across 18 scenario-by-mode groups (10 repeats each), final decisions were repeat-stable in 18/18 groups and enforced actions in 16/18 groups. Consequently, many cell-level percentages are multiples of one sixth and must not be interpreted as 60 independent scenario outcomes.

Repeat stability is an observed property of these retained responses, not a guarantee that hosted model endpoints are deterministic across future calls.

Only six scenario clusters are available. Intervals are descriptive and reliable finite-sample coverage is not asserted. Ten repeats improve repeatability assessment but do not create 60 independent scenarios.
