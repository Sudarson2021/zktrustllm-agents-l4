# Prospective pilot_02 amendment — 2026-10-16

Recorded before pilot_02 inference.

- pilot_01 is preserved, including its failures.
- pilot_01 recorded eight Mistral HTTP 429 responses,
  two Anthropic refusals and one DeepSeek recovery truncation.
- A separate pre-activation Mistral diagnostic reported zero requests/minute.
- After account activation, a diagnostic returned HTTP 200,
  with limits of 1000 requests/minute and 500000 tokens/minute.
- The common role-output cap increases from 4500 to 8192 tokens.
- The assessor-output cap remains 5000 tokens.
- Frozen inputs, prompts, conditions and trial order remain unchanged.
- Provider refusals remain observed outcomes.
- Pilot data will not be pooled into the separate full study.
