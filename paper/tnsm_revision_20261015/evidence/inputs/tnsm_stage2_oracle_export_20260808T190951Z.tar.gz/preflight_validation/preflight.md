# TNSM experiment preflight

Generated: `2026-08-08T19:09:52+00:00`

This is a read-only inventory. It made no provider calls and recorded no secret values.

## Gate status

| Gate | Status |
|---|---|
| Frozen experiment directory | PASS |
| Frozen summary | PASS |
| Six scenario sources | PASS |
| Canonical 180-row oracle | PASS |
| Ready for live experiment | YES |

## Frozen source

- Experiment: `/home/sk02352/Downloads/deploy/n8n_l4_parallel/runtime/experiments/l4_oracle_20260716T131803Z_r10`
- Summary: `/home/sk02352/Downloads/deploy/n8n_l4_parallel/runtime/experiments/l4_oracle_20260716T131803Z_r10/analysis_oracle_final/summary_by_mode.csv`
- n8n root: `/home/sk02352/Downloads/deploy/n8n_l4_parallel`
- Git branch/commit: `tnsm-supervisor-revision-step1-20260808-1837` / `a0f91567a3a011b06831aafb2f0bd5aeb0c88dd4`
- Git worktree dirty: `False` (0 paths)

## Compute

| Item | Value |
|---|---|
| OS | Linux-6.8.0-136-generic-x86_64-with-glibc2.39 |
| CPU | 11th Gen Intel(R) Core(TM) i7-1185G7 @ 3.00GHz |
| Logical CPUs | 8 |
| RAM | 31822 MiB |
| GPU | No NVIDIA GPU reported |
| Free disk at experiment | 519696 MiB |

## Tool and credential-presence checks

| Tool | Available | Version |
|---|---|---|
| python3 | yes | Python 3.12.3 |
| git | yes | git version 2.43.0 |
| docker | yes | Docker version 29.1.3, build 29.1.3-0ubuntu3~24.04.2 |
| docker_compose | yes | Docker Compose version v5.1.2 |
| ollama | yes | ollama version is 0.12.3 |
| curl | yes | curl 8.5.0 (x86_64-pc-linux-gnu) libcurl/8.5.0 OpenSSL/3.0.13 zlib/1.3 brotli/1.1.0 zstd/1.5.5 libidn2/2.3.7 libpsl/0.21.2 (+libidn2/2.3.7) libssh/0.10.6/openssl/zlib nghttp2/1.59.0 librtmp/2.3 OpenLDAP/2.6.7 |

Only presence is shown; no credential value was read into the report.

| Environment variable | Present |
|---|---|
| OPENAI_API_KEY | yes |
| ANTHROPIC_API_KEY | no |
| DEEPSEEK_API_KEY | no |
| MISTRAL_API_KEY | no |
| COHERE_API_KEY | no |

## Scenario sources

| ID | Path | Bytes | SHA-256 |
|---|---|---|---|
| S1 | scenarios/configs/S1_compliant_baseline.json | 262 | f6151bea3dfc978a7a6f1baffe8ce97deec9d33242167e80a09220f5fdbcdad4 |
| S2 | scenarios/configs/S2_drb_integrity_disabled.json | 398 | 9308268a77a61c3e69979586f9cbeaf335f274b904ca3d099e0f0c5e007471d7 |
| S3 | scenarios/configs/S3_legacy_o1_tls.json | 215 | 1f88d3e181f914b3abc0e53529670bd43ea15476a8cd3326fc0080ca884ca814 |
| S4 | scenarios/configs/S4_unauthorised_xapp_actuation.json | 231 | 81c11bac275712da1290fdc9ce57a2a42eedcd5c8d5d8ce9a0a7fa414d28f980 |
| S5 | scenarios/configs/S5_replayed_anchor.json | 266 | c5b8f0db9bc8cc961b81e63480567929501f285063fbf90e28b962d4631df955 |
| S6 | scenarios/configs/S6_insufficient_evidence.json | 243 | c61304444cfcab1aff4ba7b910aa3dc107b8cbfa5eaf4e0309a73e142030b8a6 |

## Candidate frozen data files

| Path | Bytes | Rows | Keys/columns | SHA-256 |
|---|---|---|---|---|
| analysis_oracle_final/summary_by_scenario_mode.csv | 1396 | 18 | scenario_id, retrieval_mode, runs, decision_accuracy, enforced_action_accuracy, coverage, safe_abstention_rate, provider_validation_rate, role_validation_rate, latency_mean_sec, latency_median_sec | 0ae1010cd8a60d655b2853e0ae93b088f6a1bbb2a4f79086ff0fe3eabbcf1560 |
| oracle_scenario_manifest.json | 6468 |  | claim_boundary, description, evaluation_mode, expert_verified, manifest_version, oracle_manifest_hash, oracle_verified, oracle_version, publication_mode, scenarios, standards_manifest_hash | 941acc1d787e2e6f9b031ea33ed8c3f2d098292bb575a9725bb9e1830d169f31 |
| analysis_oracle_final/failure_category_summary.csv | 131 | 1 | failure_category, attempt_count, fraction_of_failed_attempts, fraction_of_all_attempts | b9df025b6eb5a098431d300a83182a67407251053346574d36bef0c77fb43326 |
| analysis_oracle_final/role_validation_summary.csv | 852 | 12 | retrieval_mode, role, records, valid_records, validation_rate, validation_ci95_low, validation_ci95_high | 98d8fe4b4b5ef6962545ffaf17faf98cbb1cdd979fdaa470fe66c803e18ac56e |
| analysis_oracle_final/provider_validation_summary.csv | 1200 | 12 | retrieval_mode, provider, model_id, records, valid_records, validation_rate, validation_ci95_low, validation_ci95_high | 0eb0ed85c77d260499529a22fa112e28f04ce346ef98c65bbc328cf4a5565b91 |
| analysis_oracle_final/summary_by_mode.csv | 1679 | 3 | retrieval_mode, runs, decision_correct, decision_accuracy, decision_accuracy_ci95_low, decision_accuracy_ci95_high, action_correct, enforced_action_accuracy, action_accuracy_ci95_low, action_accuracy_ci95_high, covered_runs, coverage | 0bf7a34c6a6afdfd9641ead5da07502086aed226a4cf70af68f011420b3e83c7 |
| analysis_oracle_final/role_records.csv | 51759 | 720 | scenario_id, retrieval_mode, repeat, run_id, role, valid_json, role_valid, validation_errors | 9f845227d7a185861ed6ce3b79d1df7386b4ff5b03eca0b79ec6495c471eba24 |
| analysis_oracle_final/provider_records.csv | 70366 | 720 | scenario_id, retrieval_mode, repeat, run_id, provider, model_id, provider_valid, provider_call_succeeded, valid_json, validation_errors | b7b2412bef350b917a64607086b859672e3448232140edad3c9a6cc7d4b81252 |
| analysis_oracle_final/oracle_final_analysis.json | 5963 |  | analysis_version, claim_boundary, cost_statistics_enabled, evaluation_mode, experiment_id, expert_verified, operational_summary, oracle_manifest_hash, oracle_verified, oracle_version, provider_record_count, publication_ready | 9fa387c669c3885e1a6bda4ae492667072e3c35c7cddde3ebc2d7e2392855fbb |
| final_attempt_summary.json | 1156 |  | canonical_success_matrix, duplicate_successful_cells, evaluation_mode, experiment_id, expert_verified, failed_attempt_index, failed_attempts_retained, failed_unique_cells, failure_attempts_by_mode, failure_attempts_by_scenario, pending_cells, planned_unique_cells | 707ae31e6d53d56c610e35f0944d2c840384852aa786b5230af646ea795b2eed |
| scenario_manifest_snapshot.json | 6468 |  | claim_boundary, description, evaluation_mode, expert_verified, manifest_version, oracle_manifest_hash, oracle_verified, oracle_version, publication_mode, scenarios, standards_manifest_hash | 941acc1d787e2e6f9b031ea33ed8c3f2d098292bb575a9725bb9e1830d169f31 |
| analysis_oracle_final/agentic_action_mismatches.csv | 780 | 2 | scenario_id, retrieval_mode, repeat, run_id, oracle_decision, final_decision, decision_correct, oracle_action_class, enforced_action_class, action_correct, covered, abstained | 74f868b568b7572e208facd021e6a5fe75700bd4d9854928ac508fad7c6cb218 |
| analysis_oracle_final/run_metrics.csv | 38017 | 180 | scenario_id, retrieval_mode, repeat, run_id, oracle_decision, final_decision, decision_correct, oracle_action_class, enforced_action_class, action_correct, covered, abstained | 07e59c61bbe06af4c9ee09fc6bd0d269342d5efb27dc0dd2848ee22c7949277a |
| analysis_oracle_final/agentic_action_mismatch_diagnostics.json | 72141 | 2 | aggregate, automatic_execution_enabled, enforced_action_class, final_decision, oracle_action_class, oracle_decision, policy, proof, reflection, repeat, report_hash, role_chain | e70e97c22fcb6b8e2c30c08a2043d392def5f742d4db5f7a9c2971619d1e38a5 |
| execution_summary.json | 359 |  | completed_at, experiment_id, failed_runs_this_invocation, index_path, next_command, successful_runs_this_invocation | b130422f13a948617b7d609dba62f7202ee34d9e6a4f6cd1e88be735e1b2fe0e |
| oracle_run_contract.json | 1396 |  | claim_boundary, contract_version, cost_statistics_enabled, evaluation_mode, expected_workflow_runs, experiment_id, expert_verified, oracle_manifest_hash, oracle_scenario_manifest, oracle_scenario_manifest_sha256, oracle_verified, oracle_version | d00357d7568f2bfb21c0e05821823ba70ccedfdfece7075b6b6f2d24a4ff17d0 |
| run_index_failed_attempts.csv | 22681 | 53 | experiment_id, phase, scenario_id, scenario_title, retrieval_mode, repeat, ground_truth_decision, ground_truth_action_class, expert_verified, run_id, report_hash, execution_mode | c2c59625a7467d2bbefabb64102e8064cb7d5438383af1dd1aa02787388048b6 |
| run_index_success_matrix.csv | 65075 | 180 | experiment_id, phase, scenario_id, scenario_title, retrieval_mode, repeat, ground_truth_decision, ground_truth_action_class, expert_verified, run_id, report_hash, execution_mode | d9143f5c17fffc14caa5764360b7841a191bf6ce435fffc70742fa0f545a5f5c |

## Canonical oracle validation

- Path: `/home/sk02352/zktrustllm-agents-l4/artifacts/out/tnsm_revision/oracle_export_20260808T190951Z/canonical_oracle_180.jsonl`
- SHA-256: `4854f1d42d7824ae48ae3b37d8402d468c9f11034aa26b0fd9e96a21e1196c6c`
- Rows: `180`
- Valid: `True`

## Next action

The frozen input gate passes; proceed to the external LangGraph baseline.
